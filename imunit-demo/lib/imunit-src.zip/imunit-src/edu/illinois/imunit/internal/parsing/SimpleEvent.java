package edu.illinois.imunit.internal.parsing;

public class SimpleEvent implements Event {

    private Name eventName;

    private Name threadName;

    public SimpleEvent(Name eventName, Name threadName) {
        this.eventName = eventName;
        this.threadName = threadName;
    }

    public Name getEventName() {
        return eventName;
    }

    public Name getThreadName() {
        return threadName;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((eventName == null) ? 0 : eventName.hashCode());
        result = prime * result + ((threadName == null) ? 0 : threadName.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        SimpleEvent other = (SimpleEvent) obj;
        if (eventName == null) {
            if (other.eventName != null)
                return false;
        } else if (!eventName.equals(other.eventName))
            return false;
        if (threadName == null) {
            if (other.threadName != null)
                return false;
        } else if (!threadName.equals(other.threadName))
            return false;
        return true;
    }

}
