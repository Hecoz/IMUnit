package edu.illinois.imunit.internal.parsing;

public interface Event {

}
