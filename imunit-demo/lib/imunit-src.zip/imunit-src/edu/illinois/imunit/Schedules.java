package edu.illinois.imunit;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * {@link Schedules} annotation. Consists of multiple {@link Schedule} annotations.
 * 
 * @author Vilas Jagannath (vbangal2@illinois.edu), <br/>
 *         Milos Gligoric (gliga@illinois.edu), <br/>
 *         Dongyun Jin (djin3@illinois.edu), <br/>
 *         Qingzhou Luo (qluo2@illinois.edu).
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface Schedules {

    Schedule[] value();
}