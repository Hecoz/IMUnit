package edu.illinois.imunit;

import java.io.StringReader;
import java.lang.Thread.State;
import java.lang.Thread.UncaughtExceptionHandler;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.junit.runner.notification.RunNotifier;
import org.junit.runners.BlockJUnit4ClassRunner;
import org.junit.runners.model.FrameworkMethod;
import org.junit.runners.model.InitializationError;

import edu.illinois.imunit.internal.parsing.Orderings;
import edu.illinois.imunit.internal.parsing.ParseException;
import edu.illinois.imunit.internal.parsing.ScheduleParser;

/**
 * Custom JUnit runner for IMUnit.
 * 
 * @author Vilas Jagannath (vbangal2@illinois.edu), <br/>
 *         Milos Gligoric (gliga@illinois.edu), <br/>
 *         Dongyun Jin (djin3@illinois.edu), <br/>
 *         Qingzhou Luo (qluo2@illinois.edu).
 */
public class IMUnitRunner extends BlockJUnit4ClassRunner {

    /**
     * Constants
     */
    private static final String DEADLOCK_DETECTION_DEFAULT = "true";
    private static final String DEADLOCK_DETECTION_KEY = "imunit.deadlock-detection";
    private static final boolean ENABLE_DEADLOCK_DETECTION = Boolean.parseBoolean(System.getProperty(DEADLOCK_DETECTION_KEY,
            DEADLOCK_DETECTION_DEFAULT));
    private static final String GROUP_NAME = "imunit-thread-group";
    private static final String MAIN_THREAD_NAME = "main";

    /**
     * Creates an {@link IMUnitRunner} for the given test class.
     * 
     * @param klass
     * @throws InitializationError
     */
    public IMUnitRunner(Class<?> klass) throws InitializationError {
        super(klass);
        /* Log any uncaught exceptions in child threads */
        Thread.setDefaultUncaughtExceptionHandler(new UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread t, Throwable e) {
                System.err.println("Uncaught exception in thread: " + t);
                e.printStackTrace();
            }
        });
    }

    /**
     * Collects the schedules specified for each test method and runs the test method for each
     * specified schedule, while enforcing that schedule.
     */
    @Override
    protected void runChild(final FrameworkMethod method, final RunNotifier notifier) {
        Map<String, Orderings> schedules = new HashMap<String, Orderings>();
        Schedules schsAnno = method.getAnnotation(Schedules.class);
        if (schsAnno != null) {
            for (Schedule schAnno : schsAnno.value()) {
                collectSchedule(schAnno, schedules);
            }
        }
        Schedule schAnno = method.getAnnotation(Schedule.class);
        if (schAnno != null) {
            collectSchedule(schAnno, schedules);
        }

        if (!schedules.isEmpty()) {
            for (Entry<String, Orderings> schedule : schedules.entrySet()) {
                IMUnit.setSchedule(schedule.getKey(), schedule.getValue());
                /*
                 * Create a separate thread group and thread within that group to run the imunit
                 * test
                 */
                ThreadGroup imunitGroup = new ThreadGroup(GROUP_NAME);
                Runnable imunitRunnable = new Runnable() {
                    @Override
                    public void run() {
                        IMUnitRunner.super.runChild(method, notifier);
                    }
                };
                Thread imunitThread = new Thread(imunitGroup, imunitRunnable, MAIN_THREAD_NAME);

                /* Start the imunit thread and the deadlock detection thread if required */
                imunitThread.start();
                if (ENABLE_DEADLOCK_DETECTION) {
                    Thread deadlockDetectorThread = new Thread(new DeadlockDetector(imunitGroup, imunitThread));
                    deadlockDetectorThread.setDaemon(true);
                    deadlockDetectorThread.start();
                }

                /* Wait for the imunit thread to terminate */
                try {
                    imunitThread.join();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                    System.exit(2);
                }
            }
            IMUnit.clearSchedule();
        }
        else {
            super.runChild(method, notifier);
        }
    }

    /**
     * Helper method for collecting the name and partial orders from each {@link Schedule}
     * annotation.
     * 
     * @param schAnno
     * @param schedules
     */
    private void collectSchedule(Schedule schAnno, Map<String, Orderings> schedules) {
        String schName = schAnno.name();
        schName = schName != null && schName.length() > 0 ? schName : schAnno.value();
        try {
            schedules.put(schName, new ScheduleParser(new StringReader(schAnno.value())).Orderings());
        } catch (ParseException e) {
            System.err.println("Ignoring invalid schedule: name = " + schName + " value = " + schAnno.value());
            e.printStackTrace();
        }
    }

    /**
     * Class that tries to detect deadlocks within a {@link ThreadGroup}.
     * 
     * @author Vilas
     */
    final class DeadlockDetector implements Runnable {

        private final Thread main;
        private final ThreadGroup group;

        /**
         * @param group
         *            {@link ThreadGroup} within which to detect deadlocks.
         * 
         * @param main
         *            Main {@link Thread} in the {@link ThreadGroup}.
         */
        public DeadlockDetector(ThreadGroup group, Thread main) {
            this.main = main;
            this.group = group;
        }

        @Override
        public void run() {
            /* Run while the main thread has not terminated */
            while (!main.getState().equals(State.TERMINATED)) {
                /* Sleep for a while */
                try {
                    Thread.sleep(3000);
                } catch (InterruptedException e) {
                    System.err.println("Deadlock detection thread was interrupted!");
                    e.printStackTrace();
                    // System.exit(2);
                }
                /* If all active threads are blocked/waiting its a deadlock */
                Thread[] activeThreads = new Thread[group.activeCount()];
                int numInArray = group.enumerate(activeThreads);
                if (numInArray == activeThreads.length && numInArray > 0) {
                    boolean deadlock = true;
                    for (int i = 0; i < activeThreads.length; i++) {
                        State activeState = activeThreads[i].getState();
                        if (activeState != State.BLOCKED && activeState != State.WAITING) {
                            deadlock = false;
                            break;
                        }
                    }
                    if (deadlock) {
                        System.err.println("Possible deadlock detected: ");
                        group.list();
                        System.exit(2);
                    }
                }
            }
        }
    }

}
