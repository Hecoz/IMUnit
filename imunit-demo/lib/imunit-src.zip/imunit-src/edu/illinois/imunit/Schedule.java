package edu.illinois.imunit;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * {@link Schedule} annotation. Consists of an (optional) name and (mandatory) value that specifies
 * the schedule as a comma separated list of orderings. <br/>
 * <br/>
 * The grammar for specifying the schedule is as follows: <br/>
 * <br/>
 * Schedule ::= { Ordering "," } Ordering <br/>
 * Ordering ::= Event "->" BasicEvent <br/>
 * Event ::= BasicEvent | BlockEvent <br/>
 * BasicEvent ::= EventName [ "@" ThreadName ] <br/>
 * BlockEvent ::= "[" EventName [ ":" EventName ] "]" [ "@" ThreadName ] <br/>
 * EventName ::= { Id "." } Id <br/>
 * ThreadName ::= Id
 * 
 * @author Vilas Jagannath (vbangal2@illinois.edu), <br/>
 *         Milos Gligoric (gliga@illinois.edu), <br/>
 *         Dongyun Jin (djin3@illinois.edu), <br/>
 *         Qingzhou Luo (qluo2@illinois.edu).
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface Schedule {

    String name() default "";

    String value();

}